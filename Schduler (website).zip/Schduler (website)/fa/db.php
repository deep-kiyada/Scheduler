<?php 
$connection = mysqli_connect('localhost','root','','clg_time_project');
if(!$connection){
    die("Database connection failed");
}



?>